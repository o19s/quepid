# Welcome to the Jupyterlite based notebooks

Learn more at https://jupyterlite.readthedocs.io/en/latest/

* ./examples/Snapshot Compare.ipynb is an example of measuring baseline relevancy over time.
